package com.lti.training.day2.oo.basics;

public class App {
	
	public static void main(String[] args) {
		
		System.out.println("========Student Details=========");
		Student student1 = new Student(); 
		student1.name="Roshan Murali";
		student1.college="EPCET";
		student1.doj="21st May 2019";
		
		System.out.println(student1.name+ " "+ student1.college +" " +student1.doj );	
		
		Passport  passport= new Passport();
		passport.setIssueDate("21st May 2019");
		passport.setExpiryDate("21st May 2034");
		passport.setPassportNo("2233443322");
		passport.setNameOfThePerson("ROSHAN MURALI");
		
		System.out.println("========Passport Details=========");
		
		System.out.println("Issue Date : " + passport.getIssueDate());
		System.out.println("Expiry Date : " + passport.getExpiryDate());
		System.out.println("Name of the Person : " + passport.getNameOfThePerson());
		System.out.println("Passport Number : "+ passport.getPassportNo());
		
		System.out.println("========Aadhar Details==========");
		
		AadharCard aadhar = new AadharCard();
		System.out.println("Aadhar number : " +aadhar.getAadharNo());
		System.out.println("Name on Aadhar :  "+aadhar.getName());
		System.out.println("Address on Aadhar : "+aadhar.getAddr());
		
	}
}
