package com.lti.training.day2.oo.basics;

public class DataInput {

	public static void main (String args[]) {
		
		Passport  passport= new Passport();
		passport.setIssueDate("21st May 2019");
		passport.setExpiryDate("21st May 2034");
		passport.setPassportNo("2233443322");
		passport.setNameOfThePerson("RAGHAV BANG");
		
		AadharCard aadhar = new AadharCard();
		aadhar.setAadharNo(654321);
		aadhar.setName("RAGHAV");
		aadhar.setAddr("RAJASTHAN");
		
		Employee employee= new Employee();
		
		employee.setAadharCard(aadhar);
		employee.setPassport(passport);
		employee.setDateofJoining("21st May 2019");
		employee.setEmpno(10022002);
		employee.setSalary(20000);
		employee.setName("RAGHAV");
		
		System.out.println("==========DATA UPDATED=============");
		
		System.out.println("Employee name : " + employee.getName());
		System.out.println("Employee number :"+ employee.getEmpno());
		System.out.println("Employee Salary :"+ employee.getSalary());
		System.out.println("Employee joining date : "+ employee.getDateofJoining());
		System.out.println("Employee Aadhar number : "+ employee.getAadharCard().getAadharNo());
		System.out.println("Employee Passport : "+ employee.getPassport().getPassportNo());
	}
}
